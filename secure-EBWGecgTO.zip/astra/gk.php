<?php
/**
 *
 *
 * @author Ananda Krishna <ak@getastra.com>
 * @date   2019-04-07
 */

$path_to_ms = __DIR__ . "/libraries/plugins/astra-gk/index.php";

if(file_exists($path_to_ms)){
    include_once $path_to_ms;
}